brAnd(0,0,0).
brAnd(1,0,0).
brAnd(0,1,0).
brAnd(1,1,1).

brOr(0,0,0).
brOr(0,1,1).
brOr(1,0,1).
brOr(1,1,1).


brXor(0,0,0).
brXor(0,1,1).
brXor(1,0,1).
brXor(1,1,0).

uklad(A,B,C,D,E,F,G,H,I,J,K) :- 
	brAnd(B,C,G),
	brXor(G,A,I),
	brOr(D,E,H),
	brAnd(H,F,J),
	brXor(I,J,K).

