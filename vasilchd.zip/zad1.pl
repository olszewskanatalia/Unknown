silnia(0,1).
silnia(N,Nsil) :-
	N > 0,
	M is N - 1,
	silnia(M,Msil),
	Nsil is N * Msil. 


fib(0,0).
fib(1,1).
fib(N,Nfib):-
	N > 1,
	N1 is N - 1,
	N2 is N - 2,
	fib(N1,N1fib),
	fib(N2, N2fib),
	Nfib is N1fib+N2fib.